import java.io.*;
import java.net.*;
import java.util.*;

public class spring {
	public static void main(String[] args) throws Exception {
		try {
			URL url = new URL("http://127.0.0.1:5000/api/by/nq");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();

			con.setRequestMethod("POST"); 

			con.setRequestProperty("Content-Type", "application/json; utf-8");

			con.setRequestProperty("Accept", "application/json");

			con.setDoOutput(true);

			String jsonInputString = "{\"clients_entry\" : \"Mouthpiece shall allow users to choose their own mouth shapes. Mouthpiece shall also allow a user to create their own mouth by selecting and customising different mouth shapes. Mouthpiece shall work in either offline or online mode. Mouthpiece shall synchronise and convert the audio input into an animated mouth in real-time. Mouthpiece  shall  allow  the  user  to  read  pre-determined  sentences  to  train  the  AI  neu-ral network if necessary.\",\"java_doc\" : \"Mouthpiece shall allow users to choose their own mouth shapes. Mouthpiece shall also allow a user to create their own mouth by selecting and customising different mouth shapes. Mouthpiece shall work in either offline or online mode. Mouthpiece shall synchronise and convert the audio input into an animated mouth in real-time. Mouthpiece  shall  allow  the  user  to  read  pre-determined  sentences  to  train  the  AI  neu-ral network if necessary.\"}";

			try(OutputStream os = con.getOutputStream()) {
			    byte[] input = jsonInputString.getBytes("utf-8");
			    os.write(input, 0, input.length);			
			}



			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}

			in.close();

			System.out.println(response);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
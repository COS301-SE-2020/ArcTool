package com.arcTool.gui;

public class Path {
    private String FR;
    private  String path;

    public String getFR(){
        return FR;
    }

    public String getPath() {
        return path;
    }

    public void setFR(String FR) {
        this.FR = FR;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
